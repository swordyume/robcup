from maix import camera, app
from config import COLOR_MAP
from uart_manager import UARTManager
from character_recognizer import CharacterRecognizer
from box_detector import BoxDetector
from display_manager import DisplayManager


class LeftCamApp:
    def __init__(self):
        self.uart = UARTManager()
        self.recognizer = CharacterRecognizer()
        self.detector = BoxDetector(screen_height=224)
        self.display = DisplayManager()
        self.cam = camera.Camera(
            self.detector.input_width,
            self.detector.input_height,
            self.detector.input_format,
        )

    def run(self):
        while not app.need_exit():
            self.uart.poll()
            img_raw = self.cam.read()
            img = img_raw.rotate(270)
            self._process_ocr(img)
            # if self.uart.detect_enabled:
            self.detector.update(img, self.uart.send_move)
            # else:
            #     self.detector.reset()
            self.display.show(img)

    def _process_ocr(self, img):
        results = self.recognizer.detect(img)
        for obj in results:
            text = obj.char_str()
            cmd = self.recognizer.get_color_cmd(text)
            if cmd is not None:
                self.uart.send_color(cmd)
        CharacterRecognizer.draw_results(img, results)


if __name__ == "__main__":
    LeftCamApp().run()
