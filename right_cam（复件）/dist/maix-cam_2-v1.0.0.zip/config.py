# =========================
# 模型路径
# =========================
BOX_MODEL_PATH = "/root/models/model_318026.mud"
OCR_MODEL_PATH = "/root/models/pp_ocr.mud"

# =========================
# UART 配置
# =========================
PIN_FUNCTION_MAP = {
    "A19": "UART1_TX",
    "A18": "UART1_RX",
    "A29": "UART2_RX",
    "A28": "UART2_TX",
}
UART1_DEVICE = "/dev/ttyS1"
UART2_DEVICE = "/dev/ttyS2"
UART_BAUDRATE = 115200

# =========================
# 颜色映射
# =========================
COLOR_MAP = {
    "红": 0x01,
    "绿": 0x02,
    "黄": 0x03,
    "蓝": 0x04,
    "白": 0x05,
    "橙": 0x06,
}

# =========================
# 视觉控制参数
# =========================
ALPHA = 0.3
DEADBAND_U = 6
MAX_JUMP_PIXEL = 30
CONTROL_INTERVAL_S = 0.1
K_Y = 0.01
LOST_FRAME_THRESHOLD = 3
