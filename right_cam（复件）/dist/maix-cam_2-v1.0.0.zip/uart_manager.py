import struct
from maix import uart, pinmap, err
from config import PIN_FUNCTION_MAP, UART1_DEVICE, UART2_DEVICE, UART_BAUDRATE


class UARTManager:
    def __init__(self):
        self._init_pins()
        self.uart1 = uart.UART(UART1_DEVICE, UART_BAUDRATE)
        self.uart2 = uart.UART(UART2_DEVICE, UART_BAUDRATE)

    def _init_pins(self):
        for pin, func in PIN_FUNCTION_MAP.items():
            err.check_raise(
                pinmap.set_pin_function(pin, func),
                f"Failed set pin {pin} function to {func}",
            )

    def send_color(self, cmd: int):
        packet = bytes([0x1C, 0x78, cmd, 0x28])
        self.uart1.write(packet)

    def send_direct(self):
        packet = bytes([0x1C, 0x12, 0x01, 0x28])
        self.uart1.write(packet)

    def send_move(self, distance: float):
        packet = bytes([0x1C, 0xAD]) + struct.pack("<f", distance) + bytes([0x28])
        self.uart2.write(packet)
