import struct
from maix import uart, pinmap, err
from config import PIN_FUNCTION_MAP, UART_DEVICE, UART_BAUDRATE


class UARTManager:
    def __init__(self):
        self._init_pins()
        self.uart = uart.UART(UART_DEVICE, UART_BAUDRATE)

    def _init_pins(self):
        for pin, func in PIN_FUNCTION_MAP.items():
            err.check_raise(
                pinmap.set_pin_function(pin, func),
                f"Failed set pin {pin} function to {func}",
            )

    def send_move(self, distance: float):
        packet = bytes([0x1C, 0xAD]) + struct.pack("<f", distance) + bytes([0x28])
        self.uart.write(packet)