import time
from maix import image
from config import (
    COLOR_THRESHOLDS,
    ALPHA,
    DEADBAND_U,
    MAX_JUMP_PIXEL,
    CONTROL_INTERVAL_S,
    K_Y,
    LOST_FRAME_THRESHOLD,
)


class ColorDetector:
    def __init__(self, screen_width: int):
        self.U0 = screen_width / 2
        self.last_u_filtered = self.U0
        self.target_lost = True
        self.lost_frame_count = 0
        self.last_control_time = 0.0

    def detect(self, img):
        return img.find_blobs(
            COLOR_THRESHOLDS,
            area_threshold=1000,
            pixels_threshold=1000,
        )

    def update(self, img, send_move_fn) -> list:
        blobs = self.detect(img)
        if blobs:
            self._track_target(blobs, send_move_fn)
        else:
            self._handle_lost()
        self._draw(img, blobs)
        return blobs

    def _track_target(self, blobs, send_move_fn):
        blob = max(blobs, key=lambda x: x.w() * x.h())
        u_raw = blob.x() + blob.w() / 2
        self.lost_frame_count = 0

        if self.target_lost:
            self.last_u_filtered = u_raw
            self.target_lost = False
        else:
            if abs(u_raw - self.last_u_filtered) <= MAX_JUMP_PIXEL:
                self.last_u_filtered = ALPHA * u_raw + (1 - ALPHA) * self.last_u_filtered

            delta_u = self.last_u_filtered - self.U0
            now = time.perf_counter()
            if abs(delta_u) > DEADBAND_U and (now - self.last_control_time) >= CONTROL_INTERVAL_S:
                move_y = K_Y * delta_u
                print("move:", move_y)
                send_move_fn(move_y)
                self.last_control_time = now

    def _handle_lost(self):
        self.lost_frame_count += 1
        if self.lost_frame_count >= LOST_FRAME_THRESHOLD:
            self.target_lost = True

    @staticmethod
    def _draw(img, blobs):
        for blob in blobs:
            img.draw_rect(
                blob.x(),
                blob.y(),
                blob.w(),
                blob.h(),
                image.COLOR_GREEN,
            )