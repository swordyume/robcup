# =========================
# UART 配置
# =========================
PIN_FUNCTION_MAP = {
    "A29": "UART2_RX",
    "A28": "UART2_TX",
}
UART_DEVICE = "/dev/ttyS2"
UART_BAUDRATE = 115200

# =========================
# 颜色阈值
# =========================
COLOR_THRESHOLDS = [
    [0, 80, 40, 80, 10, 80],       # 红色
    [50, 80, -15, 10, -30, 0],      # 蓝色
]

# =========================
# 视觉控制参数
# =========================
ALPHA = 0.3
DEADBAND_U = 6
MAX_JUMP_PIXEL = 30
CONTROL_INTERVAL_S = 0.1
K_Y = 0.01
LOST_FRAME_THRESHOLD = 3