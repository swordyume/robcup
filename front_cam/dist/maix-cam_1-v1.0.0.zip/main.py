from maix import camera, app
from uart_manager import UARTManager
from color_detector import ColorDetector
from display_manager import DisplayManager


class FrontCamApp:
    def __init__(self):
        self.uart = UARTManager()
        self.detector = ColorDetector(screen_width=320)
        self.display = DisplayManager()
        self.cam = camera.Camera(320, 240)

    def run(self):
        while not app.need_exit():
            img = self.cam.read()
            self.detector.update(img, self.uart.send_move)
            self.display.show(img)


if __name__ == "__main__":
    FrontCamApp().run()